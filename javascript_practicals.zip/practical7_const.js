// Practical 7: Use const

const country = "India";
console.log(country);

// Note: Reassigning country, for example country = "Japan",
// would cause an error because a const variable cannot be reassigned.
