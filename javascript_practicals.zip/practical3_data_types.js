// Practical 3: Store information and check data types

let name = "Sameer";
let age = 23;
let isStudent = true;

console.log(name);
console.log(age);
console.log(isStudent);

console.log(typeof name);
console.log(typeof age);
console.log(typeof isStudent);
