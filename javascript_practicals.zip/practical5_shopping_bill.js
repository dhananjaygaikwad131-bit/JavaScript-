// Practical 5: Shopping bill

let money = 1000;
let shirt = 250;
let shoes = 150;

money -= shirt;
console.log(money); // Money left after buying the shirt

money -= shoes;
console.log(money); // Money left after buying the shoes
