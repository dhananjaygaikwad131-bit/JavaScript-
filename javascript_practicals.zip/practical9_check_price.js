// Practical 9: Compare two prices

let price1 = 500;
let price2 = 3425;

console.log(price1 <= price2);
console.log(price1 > price2);

// Extra: Check whether you have enough money to buy something.
let money = 1000;
let productPrice = 750;

console.log(money >= productPrice); // true means you have enough money
